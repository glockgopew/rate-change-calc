Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# Add DWM API for dark mode title bar support
Add-Type @"
using System;
using System.Runtime.InteropServices;
public class DarkMode {
    [DllImport("dwmapi.dll", CharSet=CharSet.Unicode, ExactSpelling=true)]
    public static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int attrValue, int attrSize);
}
"@

# Enable DPI Awareness
[System.Windows.Forms.Application]::SetHighDpiMode([System.Windows.Forms.HighDpiMode]::PerMonitorV2)

# Info Box (Welcome/Instructions)
[System.Windows.Forms.MessageBox]::Show(
    "Welcome to the Rate of Change Calculator!`n`n" +
    "1. Enter the starting number.`n" +
    "2. Enter the ending number.`n" +
    "3. Enter the time period (in days, weeks, months, etc.).`n" +
    "4. Select the time unit (or choose 'Other' for custom output).`n`n" +
    "Press Enter or click 'Calculate' to get the average rate of change." + "`n`n" +
    "Happy calculating!",
    "Instructions",
    [System.Windows.Forms.MessageBoxButtons]::OK,
    [System.Windows.Forms.MessageBoxIcon]::Information
)

# UI Design - Form Setup
$form = New-Object Windows.Forms.Form
$form.Text = "Rate of Change Calculator"
$form.Size = '400,450'
$form.StartPosition = "CenterScreen"
$form.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedDialog
$form.MaximizeBox = $false
$form.MinimizeBox = $false
# Set dark mode background for the form
$form.BackColor = [System.Drawing.Color]::FromArgb(30, 30, 30)
$form.ForeColor = [System.Drawing.Color]::White

# Set native title bar to dark mode (Windows 10 1809+)
$useImmersiveDarkMode = 1
[DarkMode]::DwmSetWindowAttribute($form.Handle, 20, [ref]$useImmersiveDarkMode, 4) | Out-Null

# UI Components - Labels, Inputs, and Controls
$labels = @("Starting Number:", "Ending Number:", "Time:", "Time Unit:")
$inputs = @()

# Styling for UI Elements
$labelFont = New-Object System.Drawing.Font('Tahoma', 10, [System.Drawing.FontStyle]::Bold)
$textBoxFont = New-Object System.Drawing.Font('Tahoma', 10)
$btnFont = New-Object System.Drawing.Font('Tahoma', 14, [System.Drawing.FontStyle]::Bold)

# Create and position the labels and input controls
for ($i = 0; $i -lt $labels.Count; $i++) {
    # Label creation
    $lbl = New-Object Windows.Forms.Label
    $lbl.Text = $labels[$i]
    $lbl.Font = $labelFont
    $lbl.ForeColor = [System.Drawing.Color]::White
    $lbl.Location = "20,$((30 + 40 * $i))"
    $lbl.AutoSize = $true
    $form.Controls.Add($lbl)

    if ($i -eq 3) {
        # Time Unit ComboBox
        $unitCombo = New-Object Windows.Forms.ComboBox
        $unitCombo.Items.AddRange(@("Days", "Weeks", "Months", "Years", "Other"))
        $unitCombo.SelectedIndex = 0  # Default to "Days"
        $unitCombo.Location = "180,$((30 + 40 * $i))"
        $unitCombo.Width = 180
        $form.Controls.Add($unitCombo)
        $inputs += $unitCombo
    }
    else {
        $txt = New-Object Windows.Forms.TextBox
        $txt.Font = $textBoxFont
        $txt.Location = "180,$((30 + 40 * $i))"
        $txt.Width = 180
        $form.Controls.Add($txt)
        $inputs += $txt
    }
}

# Result Label
$result = New-Object Windows.Forms.Label
$result.Font = New-Object System.Drawing.Font('Tahoma', 12, [System.Drawing.FontStyle]::Italic)
$result.ForeColor = [System.Drawing.Color]::White
$result.Location = "20,220"
$result.Size = "360,30"
$form.Controls.Add($result)

# Calculate Button (centered, bigger text)
$btnCalculate = New-Object Windows.Forms.Button
$btnCalculate.Text = "Calculate"
$btnCalculate.Font = $btnFont
$btnCalculate.Location = "20,270"
$btnCalculate.Size = "360,60"
$btnCalculate.BackColor = [System.Drawing.Color]::DarkGreen
$btnCalculate.ForeColor = [System.Drawing.Color]::White
$btnCalculate.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
$btnCalculate.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
$form.Controls.Add($btnCalculate)

# Reset Button (longer, but not taller)
$btnReset = New-Object Windows.Forms.Button
$btnReset.Text = "Reset"
$btnReset.Font = $btnFont
$btnReset.Location = "20,350"
$btnReset.Size = "360,30"  # Adjust width but maintain height
$btnReset.BackColor = [System.Drawing.Color]::DarkRed
$btnReset.ForeColor = [System.Drawing.Color]::White
$btnReset.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
$form.Controls.Add($btnReset)

# Add Tooltips to controls
$toolTip = New-Object Windows.Forms.ToolTip
$toolTip.SetToolTip($inputs[0], "Enter the starting value.")
$toolTip.SetToolTip($inputs[1], "Enter the ending value.")
$toolTip.SetToolTip($inputs[2], "Enter the time period.")
$toolTip.SetToolTip($inputs[3], "Select the time unit. 'Other' will show just the rate.")

# Button Logic for Calculate
$btnCalculate.Add_Click({
    # Get input values from the textboxes and combo box
    $start = $inputs[0].Text.Trim()
    $end = $inputs[1].Text.Trim()
    $time = $inputs[2].Text.Trim()
    $unit = $inputs[3].Text.Trim()

    # Clear previous result
    $result.Text = ""

    # Basic validation
    if (-not $start) {
        $result.Text = "Please enter a starting number."
        $result.ForeColor = [System.Drawing.Color]::Red
        return
    }
    if (-not $end) {
        $result.Text = "Please enter an ending number."
        $result.ForeColor = [System.Drawing.Color]::Red
        return
    }
    if (-not $time) {
        $result.Text = "Please enter a time period."
        $result.ForeColor = [System.Drawing.Color]::Red
        return
    }

    # Validate numeric input
    if ($start -notmatch '^-?\d+(\.\d+)?$') {
        $result.Text = "Starting number must be numeric."
        $result.ForeColor = [System.Drawing.Color]::Red
        return
    }
    if ($end -notmatch '^-?\d+(\.\d+)?$') {
        $result.Text = "Ending number must be numeric."
        $result.ForeColor = [System.Drawing.Color]::Red
        return
    }
    if ($time -notmatch '^\d+(\.\d+)?$' -or [double]$time -le 0) {
        $result.Text = "Time must be a positive number."
        $result.ForeColor = [System.Drawing.Color]::Red
        return
    }

    # Convert time to days if applicable
    if ($unit -eq "Weeks") {
        $time = [double]$time * 7
    }
    elseif ($unit -eq "Months") {
        $time = [double]$time * 30
    }
    elseif ($unit -eq "Years") {
        $time = [double]$time * 365
    }

    # Calculate the rate of change
    $rate = [math]::Round(([double]$end - [double]$start) / $time, 3)

    # Format the output based on unit selection
    if ($unit -eq "Other") {
        $result.Text = "Rate of Change: $rate"
    }
    else {
        $result.Text = "Rate of Change: $rate per $unit"
    }

    # Set color based on rate sign
    if ($rate -lt 0) {
        $result.ForeColor = [System.Drawing.Color]::Red
    }
    else {
        $result.ForeColor = [System.Drawing.Color]::Green
    }

    # Clear the numeric inputs (but not the unit selection)
    $inputs[0].Text = ""
    $inputs[1].Text = ""
    $inputs[2].Text = ""
})

# Button Logic for Reset
$btnReset.Add_Click({
    # Clear all textboxes and result label
    $inputs[0].Text = ""
    $inputs[1].Text = ""
    $inputs[2].Text = ""
    $result.Text = ""
})

# Allow Enter key to trigger Calculate
$form.KeyPreview = $true
$form.Add_KeyDown({
    if ($_.KeyCode -eq [System.Windows.Forms.Keys]::Enter) {
        $btnCalculate.PerformClick()
    }
})

# Show the form
$form.ShowDialog()